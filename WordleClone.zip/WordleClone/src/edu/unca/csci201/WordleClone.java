package edu.unca.csci201;

import java.io.FileNotFoundException;


public class WordleClone {

	public static void main(String[] args) throws FileNotFoundException {

		Wordle game = new Wordle();
		game.play();


	}

}
